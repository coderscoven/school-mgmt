# school-mgmt
school mgmt with payment, requirement, etc
