<meta content="" name="descriptison">
<meta content="" name="keywords">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- .. icofont -->
<link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
<!-- .. icofont -->
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<!-- .. icofont -->
<link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
<!-- .. bootstrap -->
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- overlayScrollbars -->
<link href="assets/vendor/overlayScrollbars/css/OverlayScrollbars.min.css" rel="stylesheet">
<!-- .. animate -->
<link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
<!-- .. remixicon -->
<link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
<!-- .. carousel -->
<link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
<!-- .. select2 -->
<link href="assets/vendor/select2-bootstrap4-theme/select2-bootstrap4.min.css" rel="stylesheet">
<link href="assets/vendor/select2/css/select2.min.css" rel="stylesheet">
<!-- .. toastr -->
<link href="assets/vendor/toastr/toastr.min.css" rel="stylesheet">
<!-- .. fontawesome -->
<link href="assets/vendor/fontawesome/css/all.min.css" rel="stylesheet">
<!-- .. icheck-bootstrap -->
<link href="assets/vendor/icheck-bootstrap/icheck-bootstrap.min.css" rel="stylesheet">
<!-- .. bootstrap-icons -->
<link href="assets/vendor/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
<!-- .. datepicker -->
<!-- <link href="assets/vendor/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet"> -->
<!-- Daterange picker -->
<link rel="stylesheet" href="assets/vendor/daterangepicker/daterangepicker.css">
<!-- .. datatables -->
<link href="assets/vendor/dataTables/datatables.min.css" rel="stylesheet">
<!-- .. datatable button styling -->
<link href="assets/vendor/datatables-buttons/css/buttons.bootstrap4.css" rel="stylesheet">
<!-- .. datetimepicker -->
<link href="assets/css/jquery.datetimepicker.min.css" rel="stylesheet">
<!-- .. main theme -->
<link href="assets/css/style.css" rel="stylesheet">
<!-- .. print theme -->
<link href="assets/css/print.css" rel="stylesheet" media="print">
<!-- .. jquery-te -->
<link href="assets/css/jquery-te-1.4.0.css" rel="stylesheet">
<!-- .. jquery ui -->
<link href="assets/vendor/jquery-ui/jquery-ui.min.css" rel="stylesheet">

<!-- // fullcalendar -->
<!-- <link rel="stylesheet" href="assets/vendor/fullcalendar/main.min.css"> -->
<!-- <link rel="stylesheet" href="assets/vendor/fullcalendar-interaction/main.min.css"> -->
<!-- <link rel="stylesheet" href="assets/vendor/fullcalendar-daygrid/main.min.css">
<link rel="stylesheet" href="assets/vendor/fullcalendar-timegrid/main.min.css">
<link rel="stylesheet" href="assets/vendor/fullcalendar-bootstrap/main.min.css"> -->

<link rel="shortcut icon" href="assets/img/icon-48x48.png" type="image/x-icon">
<link rel="icon" href="assets/img/icon-48x48.png" type="image/x-icon">

<script>
    var pageNum = "<?php echo isset($_GET['page']) ? $_GET['page'] : '' ?>";
</script>