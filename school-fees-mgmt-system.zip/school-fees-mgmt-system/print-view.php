<?php
include 'classes/MainClass.php';
?>

<div class="container">

    <?php if (isset($_GET['studid'])) { ?>
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Student</h5>
                    </div>
                </div>

            </div>
        </div>
    <?php } ?>

</div>
<!-- // container -->