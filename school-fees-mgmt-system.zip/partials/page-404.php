<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="text-center card-title">Page not found</h5>
                    <p class="card-text text-center">Sorry, we coundn't find the page you were looking for. Return to <a href="<?php echo 'index.php?' . http_build_query(['page' => 'home']);  ?>" class="card-link">dashboard</a></p>
                </div>
            </div>
        </div>
    </div>
</div>