<!--The calendar -->
<div class="row mb-4 d-none">
    <div class="col-md-6">

        <div id="calendar" style="width: 100% !important"></div>

    </div>
</div>